# My Awesome Project
A short description of the project goes here.

## Installation
To install this project, follow these steps:

1. Clone the repository:
```bash
git clone https://github.com/Mirzaei81/alibabaScraper
npm install 
npm run start
```
2. configure .env file for you're likings

